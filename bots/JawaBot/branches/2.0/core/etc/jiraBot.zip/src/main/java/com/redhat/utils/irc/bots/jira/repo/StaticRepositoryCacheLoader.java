package com.redhat.utils.irc.bots.jira.repo;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class StaticRepositoryCacheLoader implements RepositoryCacheLoader {
    
    private static Map<String, RepositoryCache.Site> staticMappings;
    
    public void initialize() {
        Map<String, RepositoryCache.Site> results = new HashMap<String, RepositoryCache.Site>();
        results.put("RHQ", new RepositoryCache.Site("http://jira.rhq-project.org/browse/RHQ"));
        results.put("JOPR", new RepositoryCache.Site("http://jira.jboss.org/jira/browse/JOPR"));
        results.put("EMBJOPR", new RepositoryCache.Site("http://jira.jboss.org/jira/browse/EMBJOPR"));
        results.put("JBMANCON", new RepositoryCache.Site("http://jira.jboss.org/jira/browse/JBMANCON"));
        results.put("JBNADM", new RepositoryCache.Site("https://jira.jboss.org/jira/browse/JBNADM"));
        staticMappings = Collections.unmodifiableMap(results);
    }
    
    public Map<String, RepositoryCache.Site> loadMappings() {
        return staticMappings;
    }

    public void storeMappings(Map<String, RepositoryCache.Site> mappings) {
        // no-op, because the 
    }
}
