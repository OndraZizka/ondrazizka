package com.redhat.utils.irc.bots.jira;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class IssueCache {
    
    public class Item {
        private String response;
        private long lastTimeRequested;

        public Item(String response) {
            this.response = response;
            this.lastTimeRequested = System.currentTimeMillis();
        }

        public boolean isStale() {
            long timeInCache = System.currentTimeMillis() - this.lastTimeRequested;
            return (timeInCache > IssueCache.this.timeout);
        }

        public String getResponse() {
            this.lastTimeRequested = System.currentTimeMillis(); // reset value for timer
            return response;
        }

        public String toString() {
            return getResponse();
        }
    }

    private class IssueCacheExpiry implements Runnable {
        public void run() {
            // make a reference copy of the cache so we can iterate and modify the cache without getting
            // ConcurrentModificationException due to another thread putting new values into the cache
            Map<String, Item> referenceCopy = new HashMap<String, Item>(IssueCache.this.cache);
            for (Map.Entry<String, Item> itemEntry : referenceCopy.entrySet()) {
                System.out.println("Checking if " + itemEntry.getValue() + " isStale ");
                if (itemEntry.getValue().isStale()) {
                    System.out.println("Removing expired entry " + itemEntry.getValue());
                    IssueCache.this.cache.remove(itemEntry.getKey());
                }
            }
        }
    }

    private final Map<String, Item> cache;
    private static final IssueCache singleton = new IssueCache();
    private ScheduledThreadPoolExecutor expiryThreadPoolExecutor;
    private long timeout;
    private long expirationCheckFrequency;
    private IssueCache() {
        cache = Collections.synchronizedMap(new HashMap<String, Item>());
        timeout = 24 * 60 * 60 * 1000; // 3 hrs by default
        expirationCheckFrequency = 60 * 60 * 1000; // 15 mins by default

        expiryThreadPoolExecutor = new ScheduledThreadPoolExecutor(1); // only one expiry thread at a time
        expiryThreadPoolExecutor.scheduleWithFixedDelay(new IssueCacheExpiry(), // start checking for item expiration
            expirationCheckFrequency, // after 15 minutes
            expirationCheckFrequency, // and every 15 mins after that
            TimeUnit.MILLISECONDS);
    }

    public static IssueCache getSingleton() {
        return singleton;
    }

    public Item getItem(String key) {
        return cache.get(key.toLowerCase());
    }

    public void putItem(String key, String response) {
        cache.put(key, new Item(response));
    }

    public void removeItem(String key) {
        cache.remove(key);
    }

    public void clear() {
        cache.clear();
    }
}
