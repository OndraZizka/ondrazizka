package com.redhat.utils.irc.bots.jira;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.redhat.utils.irc.bots.jira.repo.RepositoryParser;

import org.jibble.pircbot.PircBot;

public class JiraBot extends PircBot {

    private static final Pattern JIRA_KEY_PATTERN = Pattern.compile("([A-Z]+\\-[0-9]+)", Pattern.CASE_INSENSITIVE);

    // local references for convenience, so getSingleton needn't be called all over the place
    private IssueCache issueCache = IssueCache.getSingleton();
    private RepositoryParser repositoryParser = new RepositoryParser();
    
    int quitPassword = new Random().nextInt(1000);
    final String BOT_NICK = "JiraBot";

    public JiraBot() {
        this.setName( BOT_NICK );

        // Log the quit password.
        System.out.println("\n\n  *** QUIT PASSWORD: " + quitPassword + " ***\n");
    }

    @Override
    protected void onPrivateMessage(String sender, String login, String hostname, String message) {
        handleJiraBotCommand(sender, message.toLowerCase().trim());
    }

    @Override
    public void onMessage(String channel, String sender, String login, String hostname, String message) {
        handleJiraRequest(channel, message.toLowerCase().trim());
    }
    
    void handleJiraRequest(String from, String request) {
        Set<String> jiraIDs = new HashSet<String>();
        Matcher jiraIdMatcher = JIRA_KEY_PATTERN.matcher( request );
        while( jiraIdMatcher.find() ){
            jiraIDs.add( jiraIdMatcher.group().toLowerCase() );
        }

        if (jiraIDs.size() > 3) {
            sendMessage(from, "Don't be obnoxious, I'll answer up to three JIRA requests at a time");
        } else {
            boolean skipCache = request.contains("refresh");
            
            for (String jiraID : jiraIDs) {
                String reply = repositoryParser.getResponse( jiraID, skipCache );
                if( null != reply ){
                    sendMessage( request, reply );
                }
            }
        }
    }
    
    void handleJiraBotCommand(String from, String command) {

        if ( command.startsWith("please leave") ) {
            sendMessage(from, "Bye everyone. I'll be around; if you miss me later, /invite me.");
            this.partChannel(from, "Persona non grata.");

        } else if ( command.startsWith("diedie") ) {
            sendMessage(from, "Bye everyone, shutting down.");
            this.partChannel(from, "Warp core overload.");
            this.disconnect();

        } else if ( command.startsWith("quit " + quitPassword) ) {
            sendMessage(from, "Bye everyone, shutting down.");
            this.partChannel(from, "Warp core overload.");
            this.disconnect();

        } else if ( command.startsWith("clearcache") ) {
            String clearJiraID = command.substring(10).trim().toUpperCase();
            if ( "".equals(clearJiraID) ){
                sendMessage(from, "Clearing the cache.");
                issueCache.clear();
            } else {
                sendMessage(from, "Clearing the cache for " + clearJiraID + ".");
                issueCache.removeItem(clearJiraID);
            }

        } else if ( command.startsWith("about") ) {
            sendMessage(from, 
                "Hi, I'm a bot which brings some useful info about JIRA issues to IRC channels.");
            sendMessage(from, 
                "If you want me in your channel, invite me, usually done by typing '/invite " + BOT_NICK + "' in that channel.");
            sendMessage(from, 
                "If you don't like me, kick me off. Or say 'jirabot please leave'.");
        }
    }

    @Override
    protected void onInvite(String targetNick, String sourceNick, String sourceLogin, String sourceHostname, String channel) {
        this.joinChannel(channel);
    }

    @Override
    protected void onPart(String channel, String sender, String login, String hostname) {
        // Disconnect if the bot isn't in any channel.
        System.out.println("Channels: " + this.getChannels().length  + " - " + Arrays.toString(this.getChannels()));

        // Quit if no channels left.
        if( this.getChannels().length == 0 ) {
            this.disconnect();
        }
    }

    @Override
    protected void onDisconnect() {
        this.dispose();
    }
}