package com.redhat.utils.irc.bots.jira.repo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTableCell;
import com.redhat.utils.irc.bots.jira.IssueCache;


public class RepositoryParser {
    
    private static final String[] issueProperties = new String[] {"Key", "Type", "Status", "Priority", "Assignee", "Reporter", "Votes", "Watchers"};
    private static final String cellXpathPattern = ".//td[b[normalize-space()='%s:']]/following-sibling::td[1]";
    
    private final WebClient wc;
    private IssueCache issueCache = IssueCache.getSingleton();
    private RepositoryCache repositoryCache = RepositoryCache.getSingleton();
    

    public RepositoryParser() {
        // Create HTMLUnit WebClient.
        wc = new WebClient(BrowserVersion.FIREFOX_3);
        wc.setCssEnabled(false);
        wc.setJavaScriptEnabled(false);
    }

    public String getResponse( String jiraID, boolean skipCache ) {
        String reply = null;
        jiraID = jiraID.toLowerCase();

        // There's a cached item -> get from cache and check the timeout.
        if (skipCache == false) {
            // default is to check the cache first
            IssueCache.Item resultItem = issueCache.getItem(jiraID);
            if (resultItem != null) {
                // but only set a reply if we had a cache hit
                reply = resultItem.toString();
            }
        }
        
        // skipCache == true || cache miss
        if (reply == null) {
            reply = getResponse(jiraID);
        }
        issueCache.putItem(jiraID, reply);

        return reply;
    }

    private String getResponse(String jiraID) {
        String url;
        String reply = "";
        HtmlPage page = null;
        
        String[] parts = jiraID.split("-");
        if( parts.length != 2 ) {
            // this should never happen since jiraID was implicitly validated by the JIRA_KEY_PATTERN
            throw new IllegalArgumentException( "Invalid jira ID: " + jiraID );
        }

        String repository = repositoryCache.getUrl(parts[0]);
        if (repository == null) {
            return "Do not know URL for issue " + jiraID;
        }
        url = repository  + "-" + parts[1];

        try {
            // Get the page.
            page = (HtmlPage) wc.getPage(url);
        } catch ( Exception e ) {
            return "Problem communicating with " + url + " for " + jiraID;
        }

        String title = page.getTitleText();
        title = title.replace(" - RHQ Project JIRA", "");
        title = title.replace(" - jboss.org JIRA", "");
        
        if( title.toLowerCase().contains("login required") ) {
            reply = "JIRA issue " + jiraID + " is secured. I can't login to see this issue";
        } else if( title.toUpperCase().contains("ISSUE DOES NOT EXIST") ) {
            try {
                String hostName = new URL(url).getHost();
                reply = "JIRA at " + hostName + " reports that " + jiraID + " does not exist";
            } catch (MalformedURLException murle) {
                reply = "JIRA at " + url + " reports that " + jiraID + " does not exist";
            }
        } else {
            // Issue found, read the details.
            reply = title;
            if( title.toLowerCase().startsWith( "[#" + jiraID + "]" ) ) {
                HtmlElement infoTable = page.getElementById("issuedetails");
                if ( infoTable != null ) {
                    Map<String,String> details = new HashMap<String, String>();
                    for( String key : issueProperties ) {
                        String xPath = String.format(cellXpathPattern, key);
                        HtmlTableCell td = infoTable.getFirstByXPath( xPath );
                        if ( null == td ) { 
                            continue;
                        }
                        details.put( key, td.getTextContent().trim() );
                    }
                    String status = details.get("Status");
                    String priority = details.get("Priority");
                    String assignee = details.get("Assignee");
                    reply += String.format(" [%s, %s, %s]", status, priority, assignee );
                }
                
            }
            reply += " (" + url + ")";
        }

        return reply;
    }
}
