package com.redhat.utils.irc.bots.jira.repo;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class RepositoryCache {
    
    public static class Site {
        private final String url;
        private final String username;
        private final String password;
        
        public Site(String url) {
            this(url, null, null);
        }
        
        public Site(String url, String username, String password) {
            this.url = url;
            this.username = username;
            this.password = password;
        }
        
        public boolean requiresAuthentication() {
            return username != null || password != null;
        }
        
        public String getUrl() {
            return url;
        }
        
        public String getUsername() {
            return username;
        }
        
        public String getPassword() {
            return password;
        }
    }
    
    private RepositoryCacheLoader loader;
    private final Map<String, Site> cache;
    private static final RepositoryCache singleton = new RepositoryCache();
    private RepositoryCache() {
        cache = Collections.synchronizedMap(new HashMap<String, Site>());
        setRepositoryCacheLoader(new StaticRepositoryCacheLoader());
    }
    
    public static RepositoryCache getSingleton() {
        return singleton;
    }
    
    public void setRepositoryCacheLoader(RepositoryCacheLoader loader) {
        this.loader = loader;
        loader.initialize();
        reloadMappings();
    }
    
    public void reloadMappings() {
        Map<String, Site> mappings = loader.loadMappings();
        for (Map.Entry<String, Site> siteMapping : mappings.entrySet()) {
            cache.put(siteMapping.getKey().toLowerCase(), siteMapping.getValue());
        }
    }

    
    public String getUrl(String keyPrefix) {
        Site siteForKey = cache.get(keyPrefix.toLowerCase());
        if (siteForKey == null) {
            return null;
        }
        return siteForKey.getUrl();
    }
}
