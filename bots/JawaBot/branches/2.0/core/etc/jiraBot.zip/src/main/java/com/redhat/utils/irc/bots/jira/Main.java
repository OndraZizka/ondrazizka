package com.redhat.utils.irc.bots.jira;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jibble.pircbot.IrcException;

public class Main 
{
    public static final Pattern JIRA_KEY_PATTERN = Pattern.compile("([A-Z]+\\-[0-9]+)", Pattern.CASE_INSENSITIVE);
    
    public static void main( String[] args ) {
        System.out.println( "JIRA IRC Bot" );

        // Sandbox...
        if( false ){
            String text = "Hi JBAS-514 and ANYJIRA-566 etc.";
            Matcher matcher = JIRA_KEY_PATTERN.matcher( text );
            matcher.reset(text);

            while( matcher.find() ){
                System.out.println("Matches: "+matcher.groupCount() );
                for (int i = 0; i < matcher.groupCount(); i++) {
                    System.out.println("Match "+i+": "+matcher.group(i));
                }
            }
            return;
        }

        try {
            doSomeIdling();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (IrcException ex) {
            ex.printStackTrace();
        }
    }

    private static void doSomeIdling() throws IOException, IrcException {
        JiraBot bot = new JiraBot();
        bot.setVerbose(true); // Enable debugging output.

        if( false ){
            bot.connect("irc.freenode.net"); // Connect to the IRC server.
            bot.joinChannel("#pircbot"); // Join the #pircbot channel.
        }
        else {
            bot.connect("porky.stuttgart.redhat.com"); // RedHat
            bot.joinChannel("#some");
        }
    }
}
